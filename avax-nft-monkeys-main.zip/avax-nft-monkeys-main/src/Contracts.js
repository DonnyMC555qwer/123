export const MonkeyContract = "0x9735F88Fa1c0Fbfea22d8A0857B0BBc649AC5047";
export const MarketplaceContract = "0x8Da0Bb47352d966bC6aa8608832B4AbDa235911A";