//put in moralis database for big project

export const monkeyRanking = [
  {
    "edition": 217,
    "name": "Avax Monkeys 217",
    "rarity_score": 118.99,
    "rank": 1
  },
  {
    "edition": 154,
    "name": "Avax Monkeys 154",
    "rarity_score": 113.76,
    "rank": 2
  },
  {
    "edition": 82,
    "name": "Avax Monkeys 82",
    "rarity_score": 103.46,
    "rank": 3
  },
  {
    "edition": 141,
    "name": "Avax Monkeys 141",
    "rarity_score": 102.91,
    "rank": 4
  },
  {
    "edition": 171,
    "name": "Avax Monkeys 171",
    "rarity_score": 100.39,
    "rank": 5
  },
  {
    "edition": 71,
    "name": "Avax Monkeys 71",
    "rarity_score": 100.2,
    "rank": 6
  },
  { "edition": 27, "name": "Avax Monkeys 27", "rarity_score": 99.3, "rank": 7 },
  {
    "edition": 115,
    "name": "Avax Monkeys 115",
    "rarity_score": 98.3,
    "rank": 8
  },
  {
    "edition": 111,
    "name": "Avax Monkeys 111",
    "rarity_score": 98.26,
    "rank": 9
  },
  {
    "edition": 192,
    "name": "Avax Monkeys 192",
    "rarity_score": 96.22,
    "rank": 10
  },
  {
    "edition": 79,
    "name": "Avax Monkeys 79",
    "rarity_score": 94.24,
    "rank": 11
  },
  {
    "edition": 210,
    "name": "Avax Monkeys 210",
    "rarity_score": 92.37,
    "rank": 12
  },
  {
    "edition": 178,
    "name": "Avax Monkeys 178",
    "rarity_score": 92.12,
    "rank": 13
  },
  {
    "edition": 84,
    "name": "Avax Monkeys 84",
    "rarity_score": 91.99,
    "rank": 14
  },
  {
    "edition": 42,
    "name": "Avax Monkeys 42",
    "rarity_score": 91.63,
    "rank": 15
  },
  {
    "edition": 85,
    "name": "Avax Monkeys 85",
    "rarity_score": 91.16,
    "rank": 16
  },
  {
    "edition": 61,
    "name": "Avax Monkeys 61",
    "rarity_score": 90.73,
    "rank": 17
  },
  {
    "edition": 113,
    "name": "Avax Monkeys 113",
    "rarity_score": 90.62,
    "rank": 18
  },
  {
    "edition": 75,
    "name": "Avax Monkeys 75",
    "rarity_score": 89.89,
    "rank": 19
  },
  {
    "edition": 110,
    "name": "Avax Monkeys 110",
    "rarity_score": 88.64,
    "rank": 20
  },
  {
    "edition": 182,
    "name": "Avax Monkeys 182",
    "rarity_score": 87.36,
    "rank": 21
  },
  {
    "edition": 148,
    "name": "Avax Monkeys 148",
    "rarity_score": 87.18,
    "rank": 22
  },
  {
    "edition": 92,
    "name": "Avax Monkeys 92",
    "rarity_score": 86.59,
    "rank": 23
  },
  {
    "edition": 193,
    "name": "Avax Monkeys 193",
    "rarity_score": 85.81,
    "rank": 24
  },
  {
    "edition": 167,
    "name": "Avax Monkeys 167",
    "rarity_score": 85.62,
    "rank": 25
  },
  {
    "edition": 120,
    "name": "Avax Monkeys 120",
    "rarity_score": 85.27,
    "rank": 26
  },
  {
    "edition": 181,
    "name": "Avax Monkeys 181",
    "rarity_score": 85.2,
    "rank": 27
  },
  {
    "edition": 143,
    "name": "Avax Monkeys 143",
    "rarity_score": 84.4,
    "rank": 28
  },
  {
    "edition": 45,
    "name": "Avax Monkeys 45",
    "rarity_score": 83.99,
    "rank": 29
  },
  {
    "edition": 22,
    "name": "Avax Monkeys 22",
    "rarity_score": 83.78,
    "rank": 30
  },
  {
    "edition": 90,
    "name": "Avax Monkeys 90",
    "rarity_score": 83.24,
    "rank": 31
  },
  {
    "edition": 163,
    "name": "Avax Monkeys 163",
    "rarity_score": 82.94,
    "rank": 32
  },
  {
    "edition": 170,
    "name": "Avax Monkeys 170",
    "rarity_score": 82.55,
    "rank": 33
  },
  {
    "edition": 74,
    "name": "Avax Monkeys 74",
    "rarity_score": 82.42,
    "rank": 34
  },
  {
    "edition": 25,
    "name": "Avax Monkeys 25",
    "rarity_score": 81.41,
    "rank": 35
  },
  {
    "edition": 138,
    "name": "Avax Monkeys 138",
    "rarity_score": 80.71,
    "rank": 36
  },
  {
    "edition": 57,
    "name": "Avax Monkeys 57",
    "rarity_score": 80.1,
    "rank": 37
  },
  {
    "edition": 51,
    "name": "Avax Monkeys 51",
    "rarity_score": 79.24,
    "rank": 38
  },
  {
    "edition": 104,
    "name": "Avax Monkeys 104",
    "rarity_score": 78.82,
    "rank": 39
  },
  {
    "edition": 139,
    "name": "Avax Monkeys 139",
    "rarity_score": 77.64,
    "rank": 40
  },
  {
    "edition": 207,
    "name": "Avax Monkeys 207",
    "rarity_score": 77.26,
    "rank": 41
  },
  {
    "edition": 13,
    "name": "Avax Monkeys 13",
    "rarity_score": 77.11,
    "rank": 42
  },
  {
    "edition": 183,
    "name": "Avax Monkeys 183",
    "rarity_score": 77.07,
    "rank": 43
  },
  {
    "edition": 153,
    "name": "Avax Monkeys 153",
    "rarity_score": 76.25,
    "rank": 44
  },
  {
    "edition": 36,
    "name": "Avax Monkeys 36",
    "rarity_score": 75.35,
    "rank": 45
  },
  {
    "edition": 157,
    "name": "Avax Monkeys 157",
    "rarity_score": 75.06,
    "rank": 46
  },
  { "edition": 8, "name": "Avax Monkeys 8", "rarity_score": 74.23, "rank": 47 },
  {
    "edition": 29,
    "name": "Avax Monkeys 29",
    "rarity_score": 73.91,
    "rank": 48
  },
  {
    "edition": 96,
    "name": "Avax Monkeys 96",
    "rarity_score": 73.79,
    "rank": 49
  },
  {
    "edition": 121,
    "name": "Avax Monkeys 121",
    "rarity_score": 72.71,
    "rank": 50
  },
  {
    "edition": 134,
    "name": "Avax Monkeys 134",
    "rarity_score": 72.39,
    "rank": 51
  },
  {
    "edition": 91,
    "name": "Avax Monkeys 91",
    "rarity_score": 71.84,
    "rank": 52
  },
  {
    "edition": 97,
    "name": "Avax Monkeys 97",
    "rarity_score": 70.88,
    "rank": 53
  },
  { "edition": 5, "name": "Avax Monkeys 5", "rarity_score": 70.43, "rank": 54 },
  {
    "edition": 19,
    "name": "Avax Monkeys 19",
    "rarity_score": 69.78,
    "rank": 55
  },
  {
    "edition": 135,
    "name": "Avax Monkeys 135",
    "rarity_score": 69.7,
    "rank": 56
  },
  {
    "edition": 185,
    "name": "Avax Monkeys 185",
    "rarity_score": 69.47,
    "rank": 57
  },
  {
    "edition": 199,
    "name": "Avax Monkeys 199",
    "rarity_score": 69.32,
    "rank": 58
  },
  {
    "edition": 39,
    "name": "Avax Monkeys 39",
    "rarity_score": 68.99,
    "rank": 59
  },
  {
    "edition": 103,
    "name": "Avax Monkeys 103",
    "rarity_score": 68.95,
    "rank": 60
  },
  {
    "edition": 26,
    "name": "Avax Monkeys 26",
    "rarity_score": 68.88,
    "rank": 61
  },
  {
    "edition": 218,
    "name": "Avax Monkeys 218",
    "rarity_score": 68.57,
    "rank": 62
  },
  {
    "edition": 38,
    "name": "Avax Monkeys 38",
    "rarity_score": 68.37,
    "rank": 63
  },
  {
    "edition": 83,
    "name": "Avax Monkeys 83",
    "rarity_score": 68.15,
    "rank": 64
  },
  { "edition": 1, "name": "Avax Monkeys 1", "rarity_score": 68.13, "rank": 65 },
  {
    "edition": 195,
    "name": "Avax Monkeys 195",
    "rarity_score": 68,
    "rank": 66
  },
  {
    "edition": 11,
    "name": "Avax Monkeys 11",
    "rarity_score": 67.76,
    "rank": 67
  },
  {
    "edition": 159,
    "name": "Avax Monkeys 159",
    "rarity_score": 67.76,
    "rank": 68
  },
  {
    "edition": 125,
    "name": "Avax Monkeys 125",
    "rarity_score": 67.54,
    "rank": 69
  },
  {
    "edition": 21,
    "name": "Avax Monkeys 21",
    "rarity_score": 67.3,
    "rank": 70
  },
  {
    "edition": 86,
    "name": "Avax Monkeys 86",
    "rarity_score": 67.22,
    "rank": 71
  },
  {
    "edition": 151,
    "name": "Avax Monkeys 151",
    "rarity_score": 67.22,
    "rank": 72
  },
  {
    "edition": 112,
    "name": "Avax Monkeys 112",
    "rarity_score": 67.2,
    "rank": 73
  },
  {
    "edition": 176,
    "name": "Avax Monkeys 176",
    "rarity_score": 66.89,
    "rank": 74
  },
  {
    "edition": 118,
    "name": "Avax Monkeys 118",
    "rarity_score": 66.85,
    "rank": 75
  },
  {
    "edition": 202,
    "name": "Avax Monkeys 202",
    "rarity_score": 66.77,
    "rank": 76
  },
  {
    "edition": 41,
    "name": "Avax Monkeys 41",
    "rarity_score": 66.6,
    "rank": 77
  },
  {
    "edition": 40,
    "name": "Avax Monkeys 40",
    "rarity_score": 66.55,
    "rank": 78
  },
  {
    "edition": 49,
    "name": "Avax Monkeys 49",
    "rarity_score": 65.62,
    "rank": 79
  },
  {
    "edition": 130,
    "name": "Avax Monkeys 130",
    "rarity_score": 64.97,
    "rank": 80
  },
  {
    "edition": 189,
    "name": "Avax Monkeys 189",
    "rarity_score": 64.74,
    "rank": 81
  },
  {
    "edition": 28,
    "name": "Avax Monkeys 28",
    "rarity_score": 64.5,
    "rank": 82
  },
  {
    "edition": 68,
    "name": "Avax Monkeys 68",
    "rarity_score": 64.15,
    "rank": 83
  },
  {
    "edition": 81,
    "name": "Avax Monkeys 81",
    "rarity_score": 63.63,
    "rank": 84
  },
  {
    "edition": 152,
    "name": "Avax Monkeys 152",
    "rarity_score": 63.44,
    "rank": 85
  },
  {
    "edition": 33,
    "name": "Avax Monkeys 33",
    "rarity_score": 63.42,
    "rank": 86
  },
  {
    "edition": 119,
    "name": "Avax Monkeys 119",
    "rarity_score": 63.37,
    "rank": 87
  },
  {
    "edition": 101,
    "name": "Avax Monkeys 101",
    "rarity_score": 62.7,
    "rank": 88
  },
  {
    "edition": 58,
    "name": "Avax Monkeys 58",
    "rarity_score": 61.92,
    "rank": 89
  },
  {
    "edition": 23,
    "name": "Avax Monkeys 23",
    "rarity_score": 61.48,
    "rank": 90
  },
  {
    "edition": 78,
    "name": "Avax Monkeys 78",
    "rarity_score": 60.56,
    "rank": 91
  },
  {
    "edition": 10,
    "name": "Avax Monkeys 10",
    "rarity_score": 60.33,
    "rank": 92
  },
  {
    "edition": 140,
    "name": "Avax Monkeys 140",
    "rarity_score": 59.9,
    "rank": 93
  },
  {
    "edition": 136,
    "name": "Avax Monkeys 136",
    "rarity_score": 59.88,
    "rank": 94
  },
  {
    "edition": 107,
    "name": "Avax Monkeys 107",
    "rarity_score": 59.86,
    "rank": 95
  },
  {
    "edition": 59,
    "name": "Avax Monkeys 59",
    "rarity_score": 59.85,
    "rank": 96
  },
  { "edition": 3, "name": "Avax Monkeys 3", "rarity_score": 59.34, "rank": 97 },
  {
    "edition": 123,
    "name": "Avax Monkeys 123",
    "rarity_score": 59.31,
    "rank": 98
  },
  {
    "edition": 18,
    "name": "Avax Monkeys 18",
    "rarity_score": 59.01,
    "rank": 99
  },
  {
    "edition": 200,
    "name": "Avax Monkeys 200",
    "rarity_score": 58.78,
    "rank": 100
  },
  {
    "edition": 15,
    "name": "Avax Monkeys 15",
    "rarity_score": 58.47,
    "rank": 101
  },
  {
    "edition": 124,
    "name": "Avax Monkeys 124",
    "rarity_score": 58.47,
    "rank": 102
  },
  {
    "edition": 100,
    "name": "Avax Monkeys 100",
    "rarity_score": 58.31,
    "rank": 103
  },
  {
    "edition": 198,
    "name": "Avax Monkeys 198",
    "rarity_score": 57.81,
    "rank": 104
  },
  {
    "edition": 80,
    "name": "Avax Monkeys 80",
    "rarity_score": 57.52,
    "rank": 105
  },
  {
    "edition": 221,
    "name": "Avax Monkeys 221",
    "rarity_score": 56.89,
    "rank": 106
  },
  {
    "edition": 162,
    "name": "Avax Monkeys 162",
    "rarity_score": 56.53,
    "rank": 107
  },
  {
    "edition": 191,
    "name": "Avax Monkeys 191",
    "rarity_score": 55.93,
    "rank": 108
  },
  {
    "edition": 60,
    "name": "Avax Monkeys 60",
    "rarity_score": 55.4,
    "rank": 109
  },
  {
    "edition": 16,
    "name": "Avax Monkeys 16",
    "rarity_score": 54.86,
    "rank": 110
  },
  {
    "edition": 54,
    "name": "Avax Monkeys 54",
    "rarity_score": 54.79,
    "rank": 111
  },
  {
    "edition": 117,
    "name": "Avax Monkeys 117",
    "rarity_score": 54.79,
    "rank": 112
  },
  {
    "edition": 165,
    "name": "Avax Monkeys 165",
    "rarity_score": 54.36,
    "rank": 113
  },
  {
    "edition": 144,
    "name": "Avax Monkeys 144",
    "rarity_score": 54.23,
    "rank": 114
  },
  {
    "edition": 116,
    "name": "Avax Monkeys 116",
    "rarity_score": 54.19,
    "rank": 115
  },
  {
    "edition": 105,
    "name": "Avax Monkeys 105",
    "rarity_score": 52.55,
    "rank": 116
  },
  {
    "edition": 63,
    "name": "Avax Monkeys 63",
    "rarity_score": 52.44,
    "rank": 117
  },
  {
    "edition": 98,
    "name": "Avax Monkeys 98",
    "rarity_score": 52.44,
    "rank": 118
  },
  {
    "edition": 69,
    "name": "Avax Monkeys 69",
    "rarity_score": 52.17,
    "rank": 119
  },
  {
    "edition": 156,
    "name": "Avax Monkeys 156",
    "rarity_score": 51.99,
    "rank": 120
  },
  {
    "edition": 37,
    "name": "Avax Monkeys 37",
    "rarity_score": 51.97,
    "rank": 121
  },
  {
    "edition": 73,
    "name": "Avax Monkeys 73",
    "rarity_score": 51.96,
    "rank": 122
  },
  {
    "edition": 173,
    "name": "Avax Monkeys 173",
    "rarity_score": 51.83,
    "rank": 123
  },
  {
    "edition": 94,
    "name": "Avax Monkeys 94",
    "rarity_score": 51.67,
    "rank": 124
  },
  {
    "edition": 137,
    "name": "Avax Monkeys 137",
    "rarity_score": 51.57,
    "rank": 125
  },
  {
    "edition": 214,
    "name": "Avax Monkeys 214",
    "rarity_score": 51.03,
    "rank": 126
  },
  {
    "edition": 169,
    "name": "Avax Monkeys 169",
    "rarity_score": 50.89,
    "rank": 127
  },
  {
    "edition": 32,
    "name": "Avax Monkeys 32",
    "rarity_score": 50.79,
    "rank": 128
  },
  {
    "edition": 196,
    "name": "Avax Monkeys 196",
    "rarity_score": 50.49,
    "rank": 129
  },
  {
    "edition": 203,
    "name": "Avax Monkeys 203",
    "rarity_score": 49.44,
    "rank": 130
  },
  {
    "edition": 56,
    "name": "Avax Monkeys 56",
    "rarity_score": 49.22,
    "rank": 131
  },
  {
    "edition": 149,
    "name": "Avax Monkeys 149",
    "rarity_score": 49.11,
    "rank": 132
  },
  {
    "edition": 114,
    "name": "Avax Monkeys 114",
    "rarity_score": 48.99,
    "rank": 133
  },
  {
    "edition": 212,
    "name": "Avax Monkeys 212",
    "rarity_score": 48.87,
    "rank": 134
  },
  {
    "edition": 2,
    "name": "Avax Monkeys 2",
    "rarity_score": 48.74,
    "rank": 135
  },
  {
    "edition": 194,
    "name": "Avax Monkeys 194",
    "rarity_score": 48.65,
    "rank": 136
  },
  {
    "edition": 6,
    "name": "Avax Monkeys 6",
    "rarity_score": 48.54,
    "rank": 137
  },
  { "edition": 9, "name": "Avax Monkeys 9", "rarity_score": 48.4, "rank": 138 },
  {
    "edition": 129,
    "name": "Avax Monkeys 129",
    "rarity_score": 48.31,
    "rank": 139
  },
  {
    "edition": 126,
    "name": "Avax Monkeys 126",
    "rarity_score": 48.25,
    "rank": 140
  },
  {
    "edition": 219,
    "name": "Avax Monkeys 219",
    "rarity_score": 48.25,
    "rank": 141
  },
  {
    "edition": 177,
    "name": "Avax Monkeys 177",
    "rarity_score": 48.14,
    "rank": 142
  },
  {
    "edition": 35,
    "name": "Avax Monkeys 35",
    "rarity_score": 47.86,
    "rank": 143
  },
  {
    "edition": 77,
    "name": "Avax Monkeys 77",
    "rarity_score": 47.64,
    "rank": 144
  },
  {
    "edition": 24,
    "name": "Avax Monkeys 24",
    "rarity_score": 47.59,
    "rank": 145
  },
  {
    "edition": 155,
    "name": "Avax Monkeys 155",
    "rarity_score": 47.59,
    "rank": 146
  },
  {
    "edition": 14,
    "name": "Avax Monkeys 14",
    "rarity_score": 47.44,
    "rank": 147
  },
  {
    "edition": 168,
    "name": "Avax Monkeys 168",
    "rarity_score": 47.08,
    "rank": 148
  },
  {
    "edition": 216,
    "name": "Avax Monkeys 216",
    "rarity_score": 46.91,
    "rank": 149
  },
  {
    "edition": 93,
    "name": "Avax Monkeys 93",
    "rarity_score": 46.47,
    "rank": 150
  },
  {
    "edition": 197,
    "name": "Avax Monkeys 197",
    "rarity_score": 46.44,
    "rank": 151
  },
  {
    "edition": 164,
    "name": "Avax Monkeys 164",
    "rarity_score": 46.12,
    "rank": 152
  },
  {
    "edition": 50,
    "name": "Avax Monkeys 50",
    "rarity_score": 46.05,
    "rank": 153
  },
  {
    "edition": 160,
    "name": "Avax Monkeys 160",
    "rarity_score": 45.94,
    "rank": 154
  },
  {
    "edition": 95,
    "name": "Avax Monkeys 95",
    "rarity_score": 45.62,
    "rank": 155
  },
  {
    "edition": 145,
    "name": "Avax Monkeys 145",
    "rarity_score": 45.34,
    "rank": 156
  },
  {
    "edition": 158,
    "name": "Avax Monkeys 158",
    "rarity_score": 45.1,
    "rank": 157
  },
  {
    "edition": 222,
    "name": "Avax Monkeys 222",
    "rarity_score": 44.63,
    "rank": 158
  },
  {
    "edition": 70,
    "name": "Avax Monkeys 70",
    "rarity_score": 44.47,
    "rank": 159
  },
  {
    "edition": 174,
    "name": "Avax Monkeys 174",
    "rarity_score": 44.37,
    "rank": 160
  },
  {
    "edition": 44,
    "name": "Avax Monkeys 44",
    "rarity_score": 44.31,
    "rank": 161
  },
  {
    "edition": 175,
    "name": "Avax Monkeys 175",
    "rarity_score": 44.14,
    "rank": 162
  },
  {
    "edition": 34,
    "name": "Avax Monkeys 34",
    "rarity_score": 44.01,
    "rank": 163
  },
  {
    "edition": 166,
    "name": "Avax Monkeys 166",
    "rarity_score": 43.78,
    "rank": 164
  },
  {
    "edition": 72,
    "name": "Avax Monkeys 72",
    "rarity_score": 43.75,
    "rank": 165
  },
  {
    "edition": 67,
    "name": "Avax Monkeys 67",
    "rarity_score": 43.67,
    "rank": 166
  },
  {
    "edition": 88,
    "name": "Avax Monkeys 88",
    "rarity_score": 43.49,
    "rank": 167
  },
  {
    "edition": 179,
    "name": "Avax Monkeys 179",
    "rarity_score": 43.43,
    "rank": 168
  },
  {
    "edition": 211,
    "name": "Avax Monkeys 211",
    "rarity_score": 43.37,
    "rank": 169
  },
  {
    "edition": 220,
    "name": "Avax Monkeys 220",
    "rarity_score": 43.24,
    "rank": 170
  },
  {
    "edition": 131,
    "name": "Avax Monkeys 131",
    "rarity_score": 42.83,
    "rank": 171
  },
  {
    "edition": 53,
    "name": "Avax Monkeys 53",
    "rarity_score": 42.69,
    "rank": 172
  },
  {
    "edition": 127,
    "name": "Avax Monkeys 127",
    "rarity_score": 42.42,
    "rank": 173
  },
  {
    "edition": 161,
    "name": "Avax Monkeys 161",
    "rarity_score": 42.42,
    "rank": 174
  },
  {
    "edition": 4,
    "name": "Avax Monkeys 4",
    "rarity_score": 42.29,
    "rank": 175
  },
  {
    "edition": 172,
    "name": "Avax Monkeys 172",
    "rarity_score": 42.2,
    "rank": 176
  },
  {
    "edition": 150,
    "name": "Avax Monkeys 150",
    "rarity_score": 42.17,
    "rank": 177
  },
  {
    "edition": 208,
    "name": "Avax Monkeys 208",
    "rarity_score": 41.91,
    "rank": 178
  },
  {
    "edition": 76,
    "name": "Avax Monkeys 76",
    "rarity_score": 41.86,
    "rank": 179
  },
  {
    "edition": 205,
    "name": "Avax Monkeys 205",
    "rarity_score": 41.59,
    "rank": 180
  },
  {
    "edition": 186,
    "name": "Avax Monkeys 186",
    "rarity_score": 41.57,
    "rank": 181
  },
  {
    "edition": 180,
    "name": "Avax Monkeys 180",
    "rarity_score": 40.86,
    "rank": 182
  },
  {
    "edition": 17,
    "name": "Avax Monkeys 17",
    "rarity_score": 40.82,
    "rank": 183
  },
  {
    "edition": 43,
    "name": "Avax Monkeys 43",
    "rarity_score": 40.68,
    "rank": 184
  },
  {
    "edition": 188,
    "name": "Avax Monkeys 188",
    "rarity_score": 40.48,
    "rank": 185
  },
  {
    "edition": 12,
    "name": "Avax Monkeys 12",
    "rarity_score": 40.34,
    "rank": 186
  },
  {
    "edition": 213,
    "name": "Avax Monkeys 213",
    "rarity_score": 40.14,
    "rank": 187
  },
  {
    "edition": 128,
    "name": "Avax Monkeys 128",
    "rarity_score": 39.98,
    "rank": 188
  },
  {
    "edition": 30,
    "name": "Avax Monkeys 30",
    "rarity_score": 39.48,
    "rank": 189
  },
  {
    "edition": 87,
    "name": "Avax Monkeys 87",
    "rarity_score": 39.47,
    "rank": 190
  },
  {
    "edition": 190,
    "name": "Avax Monkeys 190",
    "rarity_score": 39.38,
    "rank": 191
  },
  {
    "edition": 201,
    "name": "Avax Monkeys 201",
    "rarity_score": 39.2,
    "rank": 192
  },
  {
    "edition": 47,
    "name": "Avax Monkeys 47",
    "rarity_score": 39.06,
    "rank": 193
  },
  {
    "edition": 102,
    "name": "Avax Monkeys 102",
    "rarity_score": 39.01,
    "rank": 194
  },
  {
    "edition": 133,
    "name": "Avax Monkeys 133",
    "rarity_score": 38.95,
    "rank": 195
  },
  {
    "edition": 109,
    "name": "Avax Monkeys 109",
    "rarity_score": 38.87,
    "rank": 196
  },
  {
    "edition": 106,
    "name": "Avax Monkeys 106",
    "rarity_score": 38.41,
    "rank": 197
  },
  {
    "edition": 62,
    "name": "Avax Monkeys 62",
    "rarity_score": 38.07,
    "rank": 198
  },
  {
    "edition": 7,
    "name": "Avax Monkeys 7",
    "rarity_score": 37.78,
    "rank": 199
  },
  {
    "edition": 20,
    "name": "Avax Monkeys 20",
    "rarity_score": 37.49,
    "rank": 200
  },
  {
    "edition": 209,
    "name": "Avax Monkeys 209",
    "rarity_score": 37.23,
    "rank": 201
  },
  {
    "edition": 206,
    "name": "Avax Monkeys 206",
    "rarity_score": 36.8,
    "rank": 202
  },
  {
    "edition": 146,
    "name": "Avax Monkeys 146",
    "rarity_score": 36.48,
    "rank": 203
  },
  {
    "edition": 89,
    "name": "Avax Monkeys 89",
    "rarity_score": 36.37,
    "rank": 204
  },
  {
    "edition": 108,
    "name": "Avax Monkeys 108",
    "rarity_score": 36.17,
    "rank": 205
  },
  {
    "edition": 187,
    "name": "Avax Monkeys 187",
    "rarity_score": 36.07,
    "rank": 206
  },
  {
    "edition": 31,
    "name": "Avax Monkeys 31",
    "rarity_score": 35.98,
    "rank": 207
  },
  {
    "edition": 46,
    "name": "Avax Monkeys 46",
    "rarity_score": 35.91,
    "rank": 208
  },
  {
    "edition": 52,
    "name": "Avax Monkeys 52",
    "rarity_score": 35.84,
    "rank": 209
  },
  {
    "edition": 64,
    "name": "Avax Monkeys 64",
    "rarity_score": 35.68,
    "rank": 210
  },
  {
    "edition": 66,
    "name": "Avax Monkeys 66",
    "rarity_score": 35.34,
    "rank": 211
  },
  {
    "edition": 122,
    "name": "Avax Monkeys 122",
    "rarity_score": 35.33,
    "rank": 212
  },
  {
    "edition": 215,
    "name": "Avax Monkeys 215",
    "rarity_score": 35.13,
    "rank": 213
  },
  {
    "edition": 184,
    "name": "Avax Monkeys 184",
    "rarity_score": 35.09,
    "rank": 214
  },
  {
    "edition": 55,
    "name": "Avax Monkeys 55",
    "rarity_score": 34.88,
    "rank": 215
  },
  {
    "edition": 99,
    "name": "Avax Monkeys 99",
    "rarity_score": 34.83,
    "rank": 216
  },
  {
    "edition": 132,
    "name": "Avax Monkeys 132",
    "rarity_score": 34.36,
    "rank": 217
  },
  {
    "edition": 204,
    "name": "Avax Monkeys 204",
    "rarity_score": 34.32,
    "rank": 218
  },
  {
    "edition": 48,
    "name": "Avax Monkeys 48",
    "rarity_score": 33.67,
    "rank": 219
  },
  {
    "edition": 142,
    "name": "Avax Monkeys 142",
    "rarity_score": 33.51,
    "rank": 220
  },
  {
    "edition": 65,
    "name": "Avax Monkeys 65",
    "rarity_score": 33.41,
    "rank": 221
  },
  {
    "edition": 147,
    "name": "Avax Monkeys 147",
    "rarity_score": 33.24,
    "rank": 222
  }
]