export default function MonkeyLogo(){
  return (
    <img src="./images/monkeyIcon.png" alt="Monkey Logo" draggable="false" width="32px" />
  )
}