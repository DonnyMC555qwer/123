//put in moralis database for big projects

export const traitRarity = [
  {
    "trait_type": "Background",
    "value": "Bubble Gum",
    "rarity_score": 2.58
  },
  {
    "trait_type": "Background",
    "value": "Good Morning",
    "rarity_score": 2.77
  },
  {
    "trait_type": "Background",
    "value": "Mow My Lawn",
    "rarity_score": 37.04
  },
  {
    "trait_type": "Background",
    "value": "Neon Sunrise",
    "rarity_score": 18.48
  },
  {
    "trait_type": "Background",
    "value": "Solana?",
    "rarity_score": 9.65
  },
  {
    "trait_type": "Background",
    "value": "Sorbet",
    "rarity_score": 14.79
  },
  {
    "trait_type": "Hands and Feet",
    "value": "Asphalt",
    "rarity_score": 5.05
  },
  {
    "trait_type": "Hands and Feet",
    "value": "Blue Tip",
    "rarity_score": 4.83
  },
  {
    "trait_type": "Hands and Feet",
    "value": "Blues Clues",
    "rarity_score": 7.93
  },
  {
    "trait_type": "Hands and Feet",
    "value": "Hubba Bubba",
    "rarity_score": 4.72
  },
  {
    "trait_type": "Hands and Feet",
    "value": "Mojo JoJo",
    "rarity_score": 12.33
  },
  {
    "trait_type": "Hands and Feet",
    "value": "Razzle",
    "rarity_score": 5.69
  },
  {
    "trait_type": "Body and Head",
    "value": "Chewbacca",
    "rarity_score": 6.93
  },
  {
    "trait_type": "Body and Head",
    "value": "Grimace",
    "rarity_score": 4.27
  },
  {
    "trait_type": "Body and Head",
    "value": "King Kong",
    "rarity_score": 17.06
  },
  {
    "trait_type": "Body and Head",
    "value": "Snow White",
    "rarity_score": 4.53
  },
  {
    "trait_type": "Body and Head",
    "value": "Sunburnt",
    "rarity_score": 10.57
  },
  {
    "trait_type": "Body and Head",
    "value": "Turtle Time",
    "rarity_score": 24.69
  },
  {
    "trait_type": "Body and Head",
    "value": "Woodstock",
    "rarity_score": 17.06
  },
  {
    "trait_type": "Body and Head",
    "value": "Yellow Mellow",
    "rarity_score": 6.73
  },
  {
    "trait_type": "Nipples",
    "value": "FTN",
    "rarity_score": 20.2
  },
  {
    "trait_type": "Nipples",
    "value": "Imma Star",
    "rarity_score": 10.09
  },
  {
    "trait_type": "Nipples",
    "value": "On Sight",
    "rarity_score": 5.41
  },
  {
    "trait_type": "Nipples",
    "value": "Pierced",
    "rarity_score": 3.83
  },
  {
    "trait_type": "Nipples",
    "value": "Reggy",
    "rarity_score": 2.47
  },
  {
    "trait_type": "Mouth",
    "value": "Asphalt",
    "rarity_score": 5.41
  },
  {
    "trait_type": "Mouth",
    "value": "Blue Tip",
    "rarity_score": 4.72
  },
  {
    "trait_type": "Mouth",
    "value": "Blues Clues",
    "rarity_score": 6.53
  },
  {
    "trait_type": "Mouth",
    "value": "Hubba Bubba",
    "rarity_score": 4.63
  },
  {
    "trait_type": "Mouth",
    "value": "Mojo JoJo",
    "rarity_score": 17.06
  },
  {
    "trait_type": "Mouth",
    "value": "Razzle",
    "rarity_score": 5.69
  },
  {
    "trait_type": "Smile",
    "value": "All Smiles Over Here",
    "rarity_score": 5.05
  },
  {
    "trait_type": "Smile",
    "value": "Cheesy",
    "rarity_score": 11.1
  },
  {
    "trait_type": "Smile",
    "value": "OoOoAhAh",
    "rarity_score": 3.42
  },
  {
    "trait_type": "Smile",
    "value": "Oooo",
    "rarity_score": 11.1
  },
  {
    "trait_type": "Smile",
    "value": "Uh Oh",
    "rarity_score": 4.93
  },
  {
    "trait_type": "Smile",
    "value": "Vamp",
    "rarity_score": 15.85
  },
  {
    "trait_type": "Smile",
    "value": "Who You Callin Pinhead",
    "rarity_score": 15.85
  },
  {
    "trait_type": "Eyes",
    "value": "Dead",
    "rarity_score": 4.35
  },
  {
    "trait_type": "Eyes",
    "value": "Default",
    "rarity_score": 2.02
  },
  {
    "trait_type": "Eyes",
    "value": "Geeked Up",
    "rarity_score": 8.22
  },
  {
    "trait_type": "Eyes",
    "value": "Out of It",
    "rarity_score": 14.79
  },
  {
    "trait_type": "Eyes",
    "value": "Ziggy",
    "rarity_score": 11.68
  },
  {
    "trait_type": "Eyebrows",
    "value": "Angry",
    "rarity_score": 11.68
  },
  {
    "trait_type": "Eyebrows",
    "value": "Anxious",
    "rarity_score": 11.1
  },
  {
    "trait_type": "Eyebrows",
    "value": "Looking For Banana",
    "rarity_score": 9.65
  },
  {
    "trait_type": "Eyebrows",
    "value": "None",
    "rarity_score": 1.73
  },
  {
    "trait_type": "Eyebrows",
    "value": "Perplexed",
    "rarity_score": 11.68
  },
  {
    "trait_type": "Eyebrows",
    "value": "Worried",
    "rarity_score": 17.06
  },
  {
    "trait_type": "Headwear",
    "value": "Angelic",
    "rarity_score": 11.68
  },
  {
    "trait_type": "Headwear",
    "value": "Banana Head",
    "rarity_score": 5.05
  },
  {
    "trait_type": "Headwear",
    "value": "City Boy",
    "rarity_score": 15.85
  },
  {
    "trait_type": "Headwear",
    "value": "Demon Mode",
    "rarity_score": 5.55
  },
  {
    "trait_type": "Headwear",
    "value": "Have You Guys Seen My Arrow?",
    "rarity_score": 8.54
  },
  {
    "trait_type": "Headwear",
    "value": "King",
    "rarity_score": 24.69
  },
  {
    "trait_type": "Headwear",
    "value": "Stinky",
    "rarity_score": 20.2
  },
  {
    "trait_type": "Headwear",
    "value": "The Livings Easy",
    "rarity_score": 8.54
  },
  {
    "trait_type": "Headwear",
    "value": "Tune Time",
    "rarity_score": 6.73
  }
]
